# Lirena — refined Regular + original Italic

Bulgarian Cyrillic adaptation by Stiliyan Spasov / Spasov Type.
Try it: https://spasovtype.com/
Source: https://github.com/stilliyan/lirena
Portfolio: https://www.stiliyanspasov.com/

## Eight files, two uses

- Lirena-Regular-Refined.ttf and Lirena-Italic.ttf: install on your computer.
- Lirena-Regular.woff2 and Lirena-Italic.woff2: use in websites.
- fonts.css: ready-to-use web stylesheet; keep it beside both WOFF2 files.
- OFL-Instrument.txt and OFL-Cormorant.txt: original, unchanged license texts.
- README.md: these instructions and credits.

TTF is a font format, not TIFF (an image format). WOFF2 is the compressed web
version of the same outlines. No duplicate OTF/WOFF/EOT/SVG font exports are
included. The family name stays Lirena, with Regular and true Italic styles.
Uninstall the older Regular before installing the new one if your OS caches it.

## Web use

Load fonts.css, then use:

```css
.specimen { font-family: 'Lirena', serif; font-weight: 400; font-synthesis: none; }
.specimen em { font-style: italic; }
```

## Release 0.4.0 — 2026-10-05

Regular font version 0.400 refines Bulgarian в, ж and к: calmer ascender heights,
local stem/junction corrections and slightly more space around ж/к. Latin,
other glyphs, style linking, Unicode mappings, shaping tables and vertical
metrics are preserved. Italic remains the original font version 0.300, byte for
byte. This is a targeted refinement, intended for titles and short editorial text.

## Credits and licenses

Copyright 2022 The Instrument Serif Project Authors
(https://github.com/Instrument/instrument-serif).
Original design and Latin outlines: Rodrigo Fuenzalida, with direction from
Jordan Egstad, JD Hooge and Jack De Caluwé on behalf of Instrument.

Copyright 2015 the Cormorant Project Authors
(https://github.com/CatharsisFonts/Cormorant).
Bulgarian source forms: Christian Thalmann / Catharsis Fonts.

Bulgarian adaptation and Regular refinement: Stiliyan Spasov / Spasov Type.
This independent adaptation is not an official release of either source project.
Original authors retain their copyright; credits do not imply endorsement.
All font software is distributed under SIL Open Font License 1.1. Read both
included license texts. No additional commercial or exclusive license is added.

# Lirena — release v0.5.0

Bulgarian Cyrillic adaptation by Stiliyan Spasov / Spasov Type.
https://spasovtype.com/ · https://github.com/stilliyan/lirena

Regular 0.500 and original Italic 0.300, each in TTF and WOFF2.
Install Lirena-Regular-Refined.ttf and Lirena-Italic.ttf for desktop use.
Select family Lirena, Regular or Italic. Keep both WOFF2 files beside fonts.css
and load that stylesheet for web use. Use font-synthesis: none.

Regular's distinct Cyrillic capitals and lowercase are refined to Instrument
Serif's native stroke, curve, terminal and spacing system. 41 Cyrillic outlines
are revised cumulatively since 0.300, including accents. Shared Latin-derived
Cyrillic forms and all original Latin are retained. Italic remains unchanged.
Latin a and Cyrillic а are identical within each style: double-storey in Regular,
single-storey in Italic. Bulgarian forms are defaults; no alternate is required.

The eight files here are the complete compact desktop/web package. Source fonts,
build scripts, change notes and comparison proofs are in the GitHub repository.
This is a high-contrast display/editorial family; test your intended text sizes.

## Credits and licenses

Copyright 2022 The Instrument Serif Project Authors. Original Instrument Serif
Latin design by Rodrigo Fuenzalida, with direction from Jordan Egstad, JD Hooge
and Jack De Caluwé on behalf of Instrument.
https://github.com/Instrument/instrument-serif

Copyright 2015 the Cormorant Project Authors. Cormorant Garamond by Christian
Thalmann / Catharsis Fonts supplies Bulgarian source forms in the adaptation.
https://github.com/CatharsisFonts/Cormorant

Cyrillic adaptation and Regular refinement by Stiliyan Spasov / Spasov Type.
This is an independent adaptation, not an official release of either project.
All font software is distributed under SIL Open Font License 1.1. Both original
license texts and copyright notices are included unchanged. Original authors
retain copyright; credit does not imply endorsement. No exclusive license added.

# Lirena — v1.0.0

Bulgarian Cyrillic adaptation of Instrument Serif by Stiliyan Spasov / Spasov Type. First stable release: Regular and Italic, in TTF and WOFF2.

Desktop: install the two TTF files and select Lirena.
Web: keep the WOFF2 files beside fonts.css and load that stylesheet.

Based on Instrument Serif (Instrument Serif Project Authors) and selected Bulgarian forms from Cormorant Garamond (Cormorant Project Authors). Original Latin outlines and spacing are retained.

SIL Open Font License 1.1. Both original licenses are included unchanged.

https://spasovtype.com/

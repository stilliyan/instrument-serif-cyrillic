# Lirena — v0.5.7

Bulgarian Cyrillic adaptation of Instrument Serif by Stiliyan Spasov / Spasov Type.
https://spasovtype.com/ · https://github.com/stilliyan/lirena

Regular 0.570 and original Italic 0.300. TTF for desktop use, WOFF2 for web use.
Regular 0.570 softens the outer connection between the two lowercase в loops
and removes its accidental triangular pinhole. The preferred lower oval and
both main counters are retained. The pointed tops of lowercase м are lowered
12 units. All advance widths, spacing, other letters, original Latin and
Italic remain unchanged.

Install the two TTF files on your computer. For web use, keep the two WOFF2 files
beside fonts.css and load that stylesheet. Use font-family: 'Lirena', serif;
font-weight: 400; font-style: normal (or italic); font-synthesis: none.
Use lang="bg" for Bulgarian text. All 62 Bulgarian alphabet codepoints included.
Latin a and Cyrillic а are identical within each style: double-storey in Regular,
single-storey in Italic. Intended for titles and short editorial passages.

Sources: Instrument Serif, copyright 2022 the Instrument Serif Project Authors;
Cormorant Garamond, copyright 2015 the Cormorant Project Authors. Independent
adaptation; not an official release of either original project. Both source
fonts and this adaptation use the SIL Open Font License 1.1. See the two included
original OFL license files for complete terms and attribution.

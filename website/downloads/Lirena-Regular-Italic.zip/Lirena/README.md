# Lirena

Bulgarian Cyrillic adaptation of Instrument Serif.
Cyrillic adaptation by Stiliyan Spasov / Spasov Type.

Portfolio: https://www.stiliyanspasov.com/
Try the typeface: https://spasovtype.com/
Source and build scripts: https://github.com/stilliyan/lirena

## Styles and formats

Regular 400 and true Italic 400, available as TTF and WOFF2:

- Lirena-Regular.ttf
- Lirena-Italic.ttf
- Lirena-Regular.woff2
- Lirena-Italic.woff2

Bulgarian uppercase and lowercase, including Й/й and Ѝ/ѝ, plus the original
Latin alphabet, numerals and punctuation. Bulgarian forms are the defaults in
both styles. Intended for titles and short editorial passages.

## Desktop installation

Install Lirena-Regular.ttf and Lirena-Italic.ttf using your operating system's
font installer. Select the family Lirena, then Regular or Italic.
Restart applications that cache their font lists.

## Web use

Keep fonts.css beside both WOFF2 files and load the stylesheet:

```html
<link rel="stylesheet" href="fonts.css">
<p class="specimen" lang="bg">Кирилица с характер.</p>
```

```css
.specimen {
  font-family: 'Lirena', serif;
  font-weight: 400;
  font-synthesis: none;
}
.specimen em { font-style: italic; }
```

## Sources and contribution

Lirena is an independent adaptation of Instrument Serif and Cormorant Garamond.
It is not an official release of either original project.

Instrument Serif's original Latin outlines, numerals, punctuation and spacing
are preserved. Shared Cyrillic forms reuse original outlines, including Latin
m adapted as Bulgarian т. Distinct Bulgarian forms, including д and ж, use
Cormorant Garamond's Bulgarian forms, adapted to Instrument Serif's proportions.

Stiliyan Spasov / Spasov Type contributed the Bulgarian Cyrillic adaptation,
proportion matching, italic slant adjustment, Cyrillic spacing, accented-letter
composition and shared vertical metrics for the two styles.

## Credits and licenses

Copyright 2022 The Instrument Serif Project Authors.
https://github.com/Instrument/instrument-serif
Original Instrument Serif design and Latin outlines. Designed by Rodrigo
Fuenzalida, with direction from Jordan Egstad, JD Hooge and Jack De Caluwé
on behalf of Instrument.

Copyright 2015 the Cormorant Project Authors.
https://github.com/CatharsisFonts/Cormorant
Source Bulgarian Cyrillic forms from Cormorant Garamond, designed by
Christian Thalmann / Catharsis Fonts.

Cyrillic adaptation by Stiliyan Spasov / Spasov Type.

All included font software is distributed under the SIL Open Font License 1.1.
Original copyright notices and both license texts are included unchanged in
OFL-Instrument.txt and OFL-Cormorant.txt. Original authors retain their copyright.
Their credits do not imply endorsement. Font software may not be sold by itself
or relicensed under a different license. See AUTHORS.txt and FONTLOG.md.

Lirena v0.5.8 — Regular 0.580 and Italic 0.300

Lowercase ъ and ь share native Instrument bowl curves adapted to a 402-unit bowl and a 510-unit head, with advance 451. Their counters and oval curves are shared. The hard sign has a restrained upper-left flag and a lower serif, while the soft sign keeps its native rising head and curled lower return. This restores distinct signs and removes the excessive 740-unit ascender. The ю outline is unchanged.

Capital Ъ has a smaller upper flag. The б flag terminal is rounded and leveled. Lowercase ц/щ share a straighter thin descender and round end. Lowercase я retains height but is narrowed six percent.

All lowercase Cyrillic pair spacing is reviewed against native Instrument shape references. Optical adjustments are restrained to -24/+16 units before necessary full-height clearance guards. 626 Cyrillic-only pair deltas include mixed-case clearance repairs. Existing lookups and all Latin shaping remain exact. This is a controlled optical calibration, not a claim that equal numeric gaps are visually equal.

Ten outlines change, including a contour-preserving translation of д to reduce its excessive bearings (left 39→23, right 70→32, advance 460→406). Cyrillic х is raised from 480 to 500 to correct its over-shortened optical height, retaining terminal thickness and width. The ж basic bearings are reduced equally from 47 to 31, advance 668 to 636, preserving its contour shape. Original Latin, original Italic, all other outlines, vertical metrics and accents are retained. Independent contour crossing checks, WOFF2 roundtrip and a full source rebuild pass. Actual construction guides and before/after proofs include the complete lowercase line and words at 16/24/32 px. The original portfolio thumbnail is retained. The upper button keeps its original 144×40 desktop size (128×40 on small screens). The lower button is white, 224×40, with 16-unit side padding and the default arrow on the right.

Install the TTF files or use the WOFF2 files with fonts.css.

# Lirena — v0.5.6

Bulgarian Cyrillic adaptation of Instrument Serif by Stiliyan Spasov / Spasov Type.
https://spasovtype.com/ · https://github.com/stilliyan/lirena

Regular 0.560 and original Italic 0.300. TTF for desktop use, WOFF2 for web use.
Regular 0.560 lowers the optical height of Cyrillic х and opens its sidebearings.
The soft sign ь shares the approved ъ oval, counter and native head, with its own
curled lower return. Lowercase ц/щ tails now have a fully rounded terminal cap.
Two advance widths and 19 targeted Cyrillic pairs are adjusted for consistent
spacing. Other letters, original Latin and Italic remain unchanged.

Install the two TTF files on your computer. For web use, keep the two WOFF2 files
beside fonts.css and load that stylesheet. Use font-family: 'Lirena', serif;
font-weight: 400; font-style: normal (or italic); font-synthesis: none.
Use lang="bg" for Bulgarian text. All 62 Bulgarian alphabet codepoints included.
Latin a and Cyrillic а are identical within each style: double-storey in Regular,
single-storey in Italic. Intended for titles and short editorial passages.

Sources: Instrument Serif, copyright 2022 the Instrument Serif Project Authors;
Cormorant Garamond, copyright 2015 the Cormorant Project Authors. Independent
adaptation; not an official release of either original project. Both source
fonts and this adaptation use the SIL Open Font License 1.1. See the two included
original OFL license files for complete terms and attribution.
